package io.seata.samples.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import io.seata.samples.entity.Account;

/**
 *
 * @author Funkye
 * @since 2019-12-07
 */
public interface AccountMapper extends BaseMapper<Account> {

}
