package io.seata.samples.sca.common.dubbo.api;

/**
 * Created by yu.hb on 2019-10-30
 */
public interface DubboEchoService {

    String echo(String name);
}
