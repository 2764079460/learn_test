package io.seata.sample;

public class TestDatas {
    public static final String USER_ID = "U100000";
    public static final String COMMODITY_CODE = "C100000";
}
